/* *****************************************************************************
 *  Name:              Alan Turing
 *  Coursera User ID:  123456
 *  Last modified:     1/1/2019
 **************************************************************************** */

public class HelloGoodbye {
    public static void main(String[] args) {
        System.out.print("Hello " + args[0] + " and " + args[1] + ".\n");
        System.out.print("Goodbye " + args[1] + " and " + args[0] + ".\n");
    }
}
